import Header from "../../components/header/Header";
import Footer from "../../components/footer/Footer"

const Home = () => {
    return (
        <>
            <Header
            visibilidade="none"/
            >
            <main>

            </main>
            <Footer/>
        </>
    )
}

export default Home;