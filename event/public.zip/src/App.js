import './App.css';
import Rotas from './Routes/Routes.js';

function App() {
  return (
    <>
    <Rotas/>
    </>
  );
}

export default App;