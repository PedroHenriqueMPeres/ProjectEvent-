import "./Footer.css"

const Footer = () => {
    return (
        <footer>
            <p>Escola Senai de Informática - 2025</p>
        </footer>
    )
}

export default Footer;