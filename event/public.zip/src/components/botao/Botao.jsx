import "./Botao.css"

const Botao = (props) => {
    return (
        <button className="botao">{props.botao}</button>
    )
}

export default Botao;